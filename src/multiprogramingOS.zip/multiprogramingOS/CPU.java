package multiprogramingOS;

public class CPU {
	
	int IOInter;
	int norIter;
	int abnormInter;
	int Interrupt=0;
	int RAM= 192 * 1024;
	int x;
	int numJob=0;
	jobQueue<Job> JQFromHD=new jobQueue<Job>(); 
	readyQueue<PCB> RQ=new readyQueue<PCB>();
	OS os=new OS();
	IODevice iodevice=new IODevice(); 
	boolean isCPUAvailable=true; 
	
	public void pullJub(readyQueue<PCB> RQ) {
		
		while(!RQ.empty() && isCPUAvailable  ) {
			isCPUAvailable=false;
			//++numJob;
		Node<PCB> PCB=RQ.remove();
		PCB.data.setState("Running");
		int CUT=PCB.data.getCUT();
		while(PCB.data.getState().equals("Running")) {
			
			++CUT;
			if(CUT>PCB.data.getECU()) {
				PCB.data.setState("Terminated");
				JopTerminatedChecker(PCB);
				System.out.println("The Process "+PCB.data.getState()+" because CUT exceeds ECU, PID= "+PCB.data.getID()+", CUT= "+PCB.data.getCUT()+", ECU= "+PCB.data.getECU());
			}
		x = (int )(Math.random()*100+1);
		if(x>20) {
			PCB.data.setState("Interrupted");
			JopTerminatedChecker(PCB);
			System.out.println("The Process Interrupted "+" The Process "+PCB.data.getState()+" PID= "+PCB.data.getID()+", CUT= "+PCB.data.getCUT()+", ECU= "+PCB.data.getECU());
		    }
			
			
		PCB.data.setCUT(CUT);
		}
		System.out.println("I am heereee");
		
		}
		isCPUAvailable=true;
	}

		
	public void JopTerminatedChecker(Node<PCB> PCB ) {   //check how job get terminated ? 1-normally or 2-upnormally
		
		int y = (int) (Math.random() * 100 + 1);

		
            if (y <= 10) {
            	
            PCB.data.setState("Terminate normally") ;     
			norIter++;
             return;
		}
		if (y <=15 ) {
			 PCB.data.setState("Terminate abnormally") ;     
			 abnormInter++;
	             return;
		}


}
	


	
	
}
