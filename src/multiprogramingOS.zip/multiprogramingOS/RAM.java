package multiprogramingOS;

public class RAM {
	
	int RAM= 192 * 1024;
	readyQueue<PCB> RQ=new readyQueue<PCB>();
	static CPU cpu=new CPU();
	hardDisk HD=new hardDisk();
	public readyQueue<PCB> fullRAM(jobQueue<PCB> JQ) {
		while(!JQ.empty()) {
			   NodeHD<PCB> pcb2=JQ.remove ();
			   int ERM=pcb2.data.EMR;
			   System.out.println("RAM SIZE Bafor= "+RAM);
			   if(ERM<=RAM) {
			   PCB pcb=new PCB(pcb2.data.ID,"Ready",pcb2.data.ECU,pcb2.data.EMR,0,0,0);
			   RQ.insert(pcb);
			   System.out.println("Job inserted to Ready Queue: ");
			   System.out.println("ID: "+pcb2.data.ID+" ECU: "+pcb.ECU+" EMR: "+pcb2.data.EMR+" CUT: "+pcb.CUT+" IRT: "+pcb.IRT+" WT:"+pcb.WT+ " State: "+pcb.State+" Size: "+RQ.size);
			   RAM=RAM-ERM;
			   System.out.println("RAM SIZE After= "+RAM);
			   }else {
				   System.out.println("Can't add more job, the RAM is full ");
				   cpu.pullJub(RQ);
			   }
			  
		   }
		cpu.pullJub(RQ);
		
		return RQ;
	}

}
