package multiprogramingOS;

public class IODevice {
 
	IOQueue<PCB> ioQueue=new IOQueue<PCB>();
	
	public IOQueue<PCB> insertToQueue(PCB pcb){
		/*ioQueue.insert(pcb);
		int IRT=pcb.getIRT();
		boolean isWating=true;
		while(isWating) {
			IRT++;
			double randomNum = Math.random() * 1;
			double roundedRandomNumber = Math.round(randomNum * 100.0) / 100.0;
				 
				  if (roundedRandomNumber <= 0.20) {
					  RAM.
				 }else {
					  return false ; 
				 }
		}*/
		return ioQueue;
	} 
}
